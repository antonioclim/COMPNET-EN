### Solutii exercitii IPv4 (template)

Completati raspunsurile pentru fiecare exercitiu.

---

### Exercitiul 1

Adresa de retea:  
Adresa de broadcast:  
Hosturi utilizabile:  
Numar hosturi:  

---

### Exercitiul 2

Cele 8 subretele:

1.  
2.  
3.  
4.  
5.  
6.  
7.  
8.  

(Pentru fiecare: prefix, adresa de retea, broadcast)

---

### Exercitiul 3 (VLSM)

Subnet A (>= 60 hosturi):  
Prefix:  
Retea:  
Broadcast:  

Subnet B (>= 30 hosturi):  
Prefix:  
Retea:  
Broadcast:  

Subnet C (>= 10 hosturi):  
Prefix:  
Retea:  
Broadcast:  

Subnet D (P2P):  
Prefix:  
Retea:  
Broadcast:  

---

### Exercitiul 4 (VLSM)

Servere web:  
Prefix:  
Retea:  
Broadcast:  

Dispozitive IoT:  
Prefix:  
Retea:  
Broadcast:  

Management:  
Prefix:  
Retea:  
Broadcast:  

---

### Exercitiul 5 (Adrese speciale)

192.168.1.0/24:  
192.168.1.127/25:  
10.0.5.255/23:  
172.16.8.32/27:  

---

### Exercitiul 6 (Verificare)

Subnet ales:  
Output din calculator:  

