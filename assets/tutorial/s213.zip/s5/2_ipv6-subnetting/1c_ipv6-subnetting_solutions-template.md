
### Solutii exercitii IPv6 (template)

Completati raspunsurile aici.

---

### Exercitiul 1

1.  
2.  

---

### Exercitiul 2 (/48 -> /64)

Servere:  
Clienti LAN:  
IoT:  
Router-router:  

---

### Exercitiul 3 (4 subretele /64)

1.  
2.  
3.  
4.  

---

### Exercitiul 4 (Adrese host)

Servere:  
Clienti LAN:  
IoT:  
Router-router:  

---

### Exercitiul 5 (Prefixele /64)

1.  
2.  
3.  

---

### Exercitiul 6 (Explicatie)

Scrieti raspunsul aici.

