
## Sarcini Stage 1

Creați fișierul:

`stage1_rpc_intro_answers.txt`

Și răspundeți la următoarele:

1. Enumerați **3 diferențe** între RPC și REST.
2. Scrieți **2 avantaje** ale RPC și **2 dezavantaje**.
3. Explicați în 2–3 rânduri ce rol are **Protocol Buffers** în gRPC.
