### Scenariu: Bellman-Ford (distance-vector concept)

Rulare:
- python3 bellman_ford.py

Observa:
- relaxare repetata (|V|-1 iteratii)
- detectie ciclu negativ (optional)
