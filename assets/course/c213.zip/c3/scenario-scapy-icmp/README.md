### Scenariu: Scapy - ICMP echo (necesita root/admin)

#### Cerinte
- Linux (recomandat)
- scapy instalat: pip install scapy
- ruleaza ca root: sudo

#### Rulare
- sudo python3 icmp_ping.py 1.1.1.1

#### Observații
- construiesti pachet IP/ICMP in aplicatie
- primesti raspuns (sau timeout)
