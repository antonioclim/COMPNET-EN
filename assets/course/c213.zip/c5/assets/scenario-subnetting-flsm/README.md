### Scenariu: subnetting cu mască fixă (FLSM)

#### Obiectiv
Împarți o rețea /p în N subrețele egale și listezi:
- rețea, broadcast, interval host pentru fiecare

#### Rulare
- python3 flsm_split.py 192.168.23.0/24 4
