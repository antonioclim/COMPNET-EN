### Scenariu: CIDR basics (calculator IPv4)

#### Obiectiv
Pentru o adresă IPv4/prefix:
- calculezi adresa de rețea
- broadcast
- primul/ultimul host
- număr de host-uri utilizabile

#### Rulare
- python3 cidr_calc.py 192.168.23.233/24
- python3 cidr_calc.py 10.2.10.233/8
