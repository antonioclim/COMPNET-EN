### Scenariu: Dijkstra (link-state concept)

Rulare:
- python3 dijkstra.py

Observa:
- extragere din priority queue
- relaxare vecini
- “SPF tree” se poate reconstrui din predecessors
