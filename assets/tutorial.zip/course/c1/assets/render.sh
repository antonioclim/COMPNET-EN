#!/usr/bin/env bash
java -jar ../../../tools/plantuml.jar -tpng puml/*.puml -o ../images
