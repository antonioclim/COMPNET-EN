### Scenariu: prescurtare și normalizare IPv6

#### Rulare
- python3 ipv6_norm.py 2001:0000:0ef2:0000:0000:0ad8:7232:0ab8
- python3 ipv6_norm.py 2001:0:ef2::ad8:7232:ab8
