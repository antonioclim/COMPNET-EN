### Scenariu: VLSM (IPv4)

#### Obiectiv
Aloci subrețele de mărimi diferite într-un bloc dat.

#### Rulare (exemplul clasic)
- python3 vlsm_alloc.py 193.226.3.0/24 50 24 8 2 2 2

#### Output
- listează subrețelele alocate în ordine
