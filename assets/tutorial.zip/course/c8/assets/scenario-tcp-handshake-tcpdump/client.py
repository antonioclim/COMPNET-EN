import socket
import time

HOST = "127.0.0.1"
PORT = 9090

def main():
    msg = b"hello"
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((HOST, PORT))
    s.sendall(msg)
    data = s.recv(4096)
    print(f"[client] received: {data!r}")

    # Mic delay ca sa fie mai vizibila inchiderea in captura
    time.sleep(0.2)
    s.close()

if __name__ == "__main__":
    main()
