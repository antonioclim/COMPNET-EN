
## Sarcini Stage 2 – JSON-RPC Client

Creați fișierul:

`stage2_jsonrpc_output.txt`

Completați în `jsonrpc_client.py` TODO-urile:

1. citiți de la tastatură o expresie (ex: `10*5 - 3`)
2. trimiteți-o către server
3. salvați:

   * comanda tastată
   * request-ul JSON generat
   * răspunsul serverului

