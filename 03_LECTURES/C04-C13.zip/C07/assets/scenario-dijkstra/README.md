### Scenario: Dijkstra (link-state concept)

Running:
- python3 dijkstra.py

Observe:
- extraction from the priority queue
- neighbour relaxation
- the SPF tree can be reconstructed from predecessors
