### Scenario: Bellman–Ford (distance-vector concept)

Running:
- python3 bellman_ford.py

Observe:
- repeated relaxation (|V|−1 iterations)
- negative-cycle detection (optional)
