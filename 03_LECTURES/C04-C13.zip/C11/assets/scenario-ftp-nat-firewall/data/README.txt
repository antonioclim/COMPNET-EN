This directory is bind-mounted into the FTP client container. Place files here to test uploads.
