This directory serves as the FTP server root. Files uploaded by clients will appear here.
