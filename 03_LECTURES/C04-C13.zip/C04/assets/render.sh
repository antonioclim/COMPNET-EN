#!/usr/bin/env bash
java -jar ../../../00_TOOLS/plantuml.jar -tpng puml/*.puml -o ../images
