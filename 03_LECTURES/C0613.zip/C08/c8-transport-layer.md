### The transport layer
### TCP, UDP, TLS and QUIC

---

### Learning objectives
By the end of the lecture, students should be able to:
- Explain the role of the transport layer in the network architecture
- Explain the port mechanism and process multiplexing
- Describe how TCP works
- Explain the role of TCP options (MSS, SACK and window scaling)
- Compare TCP and UDP
- Understand the role of TLS/DTLS
- Understand the motivation behind QUIC

---

### The role of the transport layer
- Identifies a specific process that communicates over the network
- Bridges the network layer and the application layer
- Can provide reliability and flow control

---

### What the transport layer solves
- Process identification (ports)
- Multiplexing communications
- Flow control
- Reliability (optional, protocol dependent)

---

### Ports
- The fundamental transport-layer mechanism
- Identifies a communication endpoint
- Values between 0 and 65,535 (16 bits)

---

### Ports: client vs server
- The server uses a fixed port
- The port identifies the service
- The client chooses a free (ephemeral) port

---

### Port classification
- Well-known ports: < 1024
- Unprivileged ports: ≥ 1024
- Can be used freely

---

### Examples of well-known ports
- 80 – HTTP
- 25 – SMTP
- 21 – FTP
- 22 – SSH

---

### Transport-layer protocols
- TCP (Transmission Control Protocol)
- UDP (User Datagram Protocol)

---

### TCP vs UDP (idea)
- TCP: connection-oriented
- UDP: connectionless
- The choice depends on application requirements

---

### The TCP protocol
- Connection-oriented
- Relatively complex
- Provides transmission guarantees
- Higher overhead

---

### TCP at a high level
- Sends data as a stream
- Segments the data
- Numbers each segment

---

### The TCP header (overview)
- Contains control information
- Enables reliability and flow control

[FIG] assets/images/fig-tcp-header.png

---

### TCP: ports
- Source port (16 bits)
- Destination port (16 bits)
- Identify the processes involved

---

### TCP: segment numbering
- Sequence number (32 bits)
- Acknowledgement number (32 bits)
- Enables loss detection and reordering

---

### TCP: control fields
- Data offset
- Reserved field
- Flags

---

### TCP flags (1)
- SYN – connection initiation
- ACK – acknowledgement
- FIN – graceful closure

---

### TCP flags (2)
- RST – forced closure
- PSH – immediate delivery
- URG – urgent data

---

### TCP flags (3)
- ECE, CWR – congestion control
- Congestion appears when the network is overloaded

---

### TCP: flow control
- Window (16 bits)
- Specifies how much the receiver can accept
- Adjusted dynamically

---

### TCP: data integrity
- Checksum over header and data
- Includes the IP pseudo-header

---

### TCP options: why do they exist?
- TCP is extensible
- Options allow adaptation to modern networks
- Negotiated during the handshake (SYN)

---

### TCP option structure
- Kind (1 byte)
- Length (1 byte)
- Data (option-specific parameters)

---

### MSS – Maximum Segment Size
- Maximum size of useful data
- MSS + header = MTU
- Helps prevent IP fragmentation
- Sent only in SYN

---

### Selective Acknowledgement (SACK)
- Classic TCP acknowledges cumulatively
- SACK acknowledges ranges of data
- Reduces unnecessary retransmissions
- Requires negotiation (SACK permitted)

[FIG] assets/images/fig-tcp-sack.png

---

### Window scaling
- The window field is limited to 16 bits
- Scaling introduces a multiplication factor
- Essential for high-speed networks

---

### TCP timestamps
- TSval and TSecr
- RTT estimation
- Detects old segments (PAWS)

---

### TCP Fast Open
- Allows data to be sent in SYN
- Reduces connection latency
- Requires support on both ends

---

### NOP and End of Option List
- NOP: alignment and delimitation
- End of list: end of options

---

### TCP mechanisms (overview)
- Connection establishment
- Connection termination
- Reliability
- Flow control

---

### TCP connection establishment
- Three-way handshake
- Exchange of initial sequence numbers

[FIG] assets/images/fig-tcp-handshake.png

---

### TCP Fast Open (context)
- Reduces the classic handshake
- Data can be sent earlier

---

### TCP connection termination
- Graceful closure (four segments)
- Forced closure (RST)

[FIG] assets/images/fig-tcp-close.png

---

### Reliability in TCP
- Each segment is acknowledged
- Retransmissions on loss
- Reordering based on sequence numbers

---

### Flow control (detail)
- The window indicates receiver capacity
- It can change during the connection

---

### TCP socket states
- Reflect the connection state
- Visible at the operating-system level

---

### TCP states (1)
- CLOSED
- LISTEN
- ESTABLISHED
- FIN-WAIT-1

---

### TCP states (2)
- FIN-WAIT-2
- CLOSE-WAIT
- LAST-ACK
- CLOSING
- TIME-WAIT

TCP defines eleven states in total. Each transition is triggered by a system call or an incoming segment. The state machine governs both connection establishment and the active/passive close paths.

[FIG] assets/images/fig-tcp-states.png

---

### Protocols built on TCP
- HTTP (1.1 and 2)
- FTP
- SMTP
- other application protocols

---

### The UDP protocol
- Connectionless
- Simple
- Fast
- Minimal overhead

---

### UDP: transfer unit
- datagram
- independent messages

---

### The UDP header
- Source port
- Destination port
- Length
- Checksum

[FIG] assets/images/fig-udp-header.png

---

### UDP checksum
- Validates data integrity
- Optional in IPv4
- Mandatory in IPv6

---

### Protocols built on UDP
- DNS
- DHCP
- TFTP
- SNMP

---

### TCP vs UDP (comparison)
- TCP: reliable, ordered, stream-based
- UDP: fast, unordered, message-based
- The choice depends on the application

[FIG] assets/images/fig-tcp-vs-udp.png

---

### UDP vs TCP under loss (context)
- Real networks can experience packet loss
- UDP provides no correction mechanisms
- TCP retransmits lost segments automatically
- The difference becomes visible at the application level

---

### Scenario: UDP vs TCP with loss in Mininet
- We use Mininet to simulate a network with loss
- We introduce artificial loss on links
- We compare the behaviour of UDP and TCP applications

Topology:
- h1 --- s1 --- h2
- configurable loss on the links

[FIG] assets/images/fig-udp-vs-tcp-loss-topo.png

---

### What we track in the scenario
- UDP:
  - not all messages reach the destination
  - the application observes gaps
- TCP:
  - the application receives the full stream
  - retransmissions are transparent

---

### Why Mininet?
- It is already used in earlier lectures
- It provides fine-grained control over network conditions
- We avoid introducing a new tool
- We simulate loss without modifying applications

---

### Running the UDP vs TCP scenario (Mininet)
- Start a receiver on h2
- Send messages from h1
- Repeat the test for UDP and TCP
- Observe the difference in output

[SCENARIO] assets/scenario-udp-vs-tcp-loss/

---

### Why TLS is needed
- TCP and UDP transmit data in clear text
- An attacker can intercept traffic

---

### TLS and DTLS
- TLS: over TCP
- DTLS: over UDP
- Provides encryption and integrity

---

### TLS in the TCP/IP stack
- Runs between transport and application

[FIG] assets/images/fig-tls-stack.png

---

### TLS: core concepts
- Secure key exchange
- Symmetric encryption for data

---

### TLS protocols
- Handshake
- cipher negotiation
- alerts
- data

---

### TLS 1.3 (idea)
- Simplified handshake
- Reduced latency
- Improved security

[FIG] assets/images/fig-tls-13.png

---

### Diffie–Hellman (idea)
- Key exchange over an insecure channel
- A foundation of modern cryptography

[FIG] assets/images/fig-diffie-hellman.png

---

### QUIC
- A modern transport-layer protocol
- Runs over UDP
- Integrates security

---

### Why QUIC?
- Reduces latency
- Avoids classic TCP limitations
- Foundation for HTTP/3

---

### Establishing a QUIC connection
- 0‑RTT or 1‑RTT
- Integrated security

[FIG] assets/images/fig-quic-handshake.png

---

### Summary
- The transport layer connects the network and the application
- TCP: reliable and complex
- UDP: fast and simple
- TLS secures transport
- QUIC represents a modern evolution
