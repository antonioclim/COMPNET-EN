### Lecture 13 – IoT and security in computer networks

---

### Learning objectives

By the end of this lecture, students should be able to:

* Describe the architecture of an IoT system
* Explain the publish/subscribe model and the role of MQTT
* Run a complete IoT scenario (sensor and actuator)
* Explain the principles of vulnerability testing
* Identify basic hardening measures

---

## Part I – Internet of Things (IoT)

---

### What is an IoT system?

An IoT system is a distributed system made up of:

* resource-constrained devices
* event-driven communication
* remote control and observability

IoT is not only about sensors but also about:

* data flows
* decoupling between components
* automation

---

### Generic IoT architecture

A typical IoT system contains the following components:

* sensor
* actuator
* message broker
* backend/dashboard (optional)

[FIG] assets/images/fig-iot-architecture.png

Observation:
Components do not communicate directly but through the broker.

---

### The publish/subscribe model

In IoT, communication is:

* asynchronous
* message-oriented
* spatially and temporally decoupled

Roles:

* publisher: sends data
* subscriber: receives data
* broker: routes messages

[FIG] assets/images/fig-mqtt-pub-sub.png

---

### MQTT: why it fits IoT

Key characteristics:

* lightweight protocol
* TCP-based
* topic-based routing
* low overhead

Limitations:

* weak default security
* requires additional measures (TLS and authentication)

---

### IoT scenario: sensor and actuator

The practical scenario runs a minimal IoT system consisting of:

* a sensor that publishes temperature values
* an actuator that reacts to a threshold
* an MQTT broker

All components run as Docker containers.
[FIG] assets/images/fig-iot-scenario-runtime.png

Practical scenario:
`assets/scenario-iot-basic/`

---

### What to observe in the IoT scenario

* the sensor publishes values periodically
* the actuator reacts to events
* the broker contains no business logic
* components are fully decoupled

Important observation:
A running broker does not guarantee that publishers or subscribers are connected.

---

## Part II – Security and vulnerability testing

---

### Why security is critical in networks and IoT

Risk factors:

* a large attack surface
* unsafe default configurations
* unnecessarily exposed services
* lack of updates

IoT amplifies these risks through:

* distributed devices
* remote control
* permanent connectivity

---

### What is a vulnerability?

A vulnerability is:

* an implementation error
* a misconfiguration
* a risky design decision

Vulnerabilities can lead to:

* unauthorised access
* code execution
* data loss
* unavailability

---

### The vulnerability lifecycle

A vulnerability is not an isolated event but a process:

* an asset exists
* a vulnerability appears
* it is exploited
* it produces impact
* mitigation is required
[FIG] assets/images/fig-vulnerability-lifecycle.png

---

### Vulnerability testing: core concepts

Typical activities:

* discovery (scanning)
* service enumeration
* vulnerability identification
* controlled exploitation

Distinctions:

* vulnerability scanning
* vulnerability assessment
* penetration testing

---

### Practical scenario: a vulnerability lab

The practical scenario runs a controlled lab consisting of:

* an intentionally vulnerable target
* an attacker container
* an isolated Docker network

Purpose:

* observing a real vulnerability
* understanding the impact
[FIG] assets/images/fig-vuln-lab-architecture.png

Practical scenario:
`assets/scenario-vulnerability-lab/`

---

### What to observe in the security lab

* identifying the exposed service
* exploiting a simple vulnerability
* obtaining command execution
* evaluating the impact

Important:
This lab must be run locally only.

---

### Hardening notions

Hardening means:

* reducing the attack surface
* removing unnecessary functionality
* applying the principle of least privilege

Common measures:

* input validation
* authentication
* encryption
* network segmentation
[FIG] assets/images/fig-hardening-before-after.png

---

### Conclusions

* IoT involves distributed, message-oriented systems
* MQTT enables decoupling and scalability
* vulnerabilities are inevitable
* hardening reduces impact but does not eliminate risk
