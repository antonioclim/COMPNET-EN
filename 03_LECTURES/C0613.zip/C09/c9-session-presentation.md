### The session layer and the presentation layer
### OSI conceptual roles and modern implementations

---

### Learning objectives
By the end of the lecture, students should be able to:
- Explain the role of the session layer (L5) and the presentation layer (L6) in the OSI model
- Distinguish a connection (L4) from a session (L5)
- Understand why L5 and L6 rarely appear as separate layers today
- Identify session and presentation functions in modern systems
- Understand the link to application-layer protocols (Lecture 10)

---

### Where we are in the architecture
- So far:
  - L3: addressing and routing
  - L4: transport (TCP, UDP and TLS)
- Today:
  - L5: session (conceptual)
  - L6: presentation (conceptual)
- Next:
  - L7: application protocols (HTTP, DNS and SMTP)

[FIG] assets/images/fig-osi-l5-l6.png

---

### Why L5 and L6 can be confusing
- In the modern Internet:
  - there are no 'pure' session or presentation protocols
- Most students:
  - cannot name a concrete L5/L6 protocol
- The reason:
  - these functions have been absorbed by applications and libraries

---

### Session layer (L5): conceptual role
The session layer concerns:
- identifying a logical conversation
- maintaining state between messages
- dialogue control (who speaks when)
- timeouts, expiry and resumption

It does not define:
- data formats
- the actual transport of data

---

### Connection vs session
- Connection (L4):
  - a technical delivery mechanism (TCP, UDP)
  - exists while the socket is open
- Session (L5):
  - the logical context of an interaction
  - can survive across multiple connections

[FIG] assets/images/fig-connection-vs-session.png

---

### Stateless protocol vs stateful application
- Many protocols are stateless
- Real applications need:
  - authentication
  - continuity
  - progress (workflow)
- State is managed explicitly at a higher level

---

### Cookies: where do they fit?
- Cookies are:
  - carried by HTTP (L7)
  - interpreted by the browser and the server
- Yet they solve a typical session problem:
  - maintaining state across requests

Conclusion:
- a session-layer function
- implemented at the application layer

---

### Other modern session mechanisms
- server-side sessions (Redis, databases)
- tokens (JWT, OAuth)
- TLS session resumption
- WebSocket connections
- database sessions

All of these are:
- L5 concepts
- implemented in L7 protocols or libraries

Each mechanism solves a different aspect of state continuity: tokens carry identity across requests, TLS resumption avoids repeated handshakes and WebSocket keep-alive maintains a persistent channel.

[FIG] assets/images/fig-session-mechanisms-modern.png

---

### Presentation layer (L6): conceptual role
The presentation layer concerns:
- data representation
- character encodings
- serialisation
- compression
- (historically) encryption

Goal:
- two different systems can interpret the same data

In practice, the sender applies a pipeline of transformations — serialisation, then compression, then encryption — before handing the result to the transport layer. The receiver applies the inverse sequence.

[FIG] assets/images/fig-presentation-pipeline.png

---

### Presentation on the modern Internet
L6 functions often appear today as:
- data formats:
  - JSON, XML, Protocol Buffers
- encodings:
  - UTF‑8
- compression:
  - gzip, brotli
- content types:
  - MIME types

---

### MIME: a clear presentation example
- MIME describes what the data represents
- Format: type/subtype
- Examples:
  - text/html
  - application/json
  - image/png

[FIG] assets/images/fig-mime-examples.png

---

### Content-Type vs Content-Encoding
- Content-Type:
  - the meaning of the data (what it is)
- Content-Encoding:
  - the wrapping/encoding used for transfer (how it is sent)

Example:
- Content-Type: text/html; charset=utf-8
- Content-Encoding: gzip

[FIG] assets/images/fig-content-type-vs-encoding.png

---

### Base64: a classic presentation problem
- Some channels are text-oriented
- Binary data must be transformed
- Base64:
  - binary → text
  - increases data size

---

### Where did encryption go from L6?
- In OSI, encryption sat at the presentation layer
- On the Internet:
  - encryption moved into TLS
  - between transport and application
- Rationale:
  - security needed to be standardised and reusable

---

### L5 and L6 today: the key conclusion
- They are not separate wire-level layers anymore
- They remain:
  - design problems
  - logical responsibilities
- Implemented through:
  - application protocols
  - frameworks
  - middleware

---

### Recognising L5 vs L6 in practice
- If you see:
  - session, cookie, token, timeout
  → a session problem (L5)
- If you see:
  - JSON, UTF‑8, gzip, MIME
  → a presentation problem (L6)

---

### Link to Lecture 10
- HTTP:
  - is an application-layer protocol (L7)
  - incorporates L5 and L6 functions
- Next:
  - HTTP methods
  - status codes
  - REST and APIs

---

### Summary
- L5 (session): logical state of a conversation
- L6 (presentation): data representation
- Today:
  - not separate layers
  - but conceptually essential
- Lecture 10: HTTP as a complete L7 example
