## Tasks – Part 1

Create a file named:

`stage1_rpc_intro_answers.txt`

and answer the following:

1. List **three differences** between RPC and REST.
2. Write **two advantages** of RPC and **two disadvantages**.
3. Explain in 2–3 sentences the role of **Protocol Buffers** in gRPC.
