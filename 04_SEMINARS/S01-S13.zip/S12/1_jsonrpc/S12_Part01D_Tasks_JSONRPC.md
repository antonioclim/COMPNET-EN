## Tasks – Part 2 (JSON-RPC client)

Create a file named:

`stage2_jsonrpc_output.txt`

Complete the TODO sections in `S12_Part01_Script_JSONRPC_Client.py`:

1. read an expression from the keyboard (e.g. `10*5 - 3`)
2. send it to the server via JSON-RPC
3. save in the output file:

   - the typed expression
   - the generated JSON request
   - the server response
