
### IPv6 Exercise Solutions (Template)

Fill in your answers here.

---

### Exercise 1

1.  
2.  

---

### Exercise 2 (/48 → /64)

Servers:  
LAN clients:  
IoT:  
Router-to-router:  

---

### Exercise 3 (4 /64 subnets)

1.  
2.  
3.  
4.  

---

### Exercise 4 (Host addresses)

Servers:  
LAN clients:  
IoT:  
Router-to-router:  

---

### Exercise 5 (/64 prefixes)

1.  
2.  
3.  

---

### Exercise 6 (Explanation)

Write your answer here.
